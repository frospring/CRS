#!/bin/bash
# 自动获取脚本所在目录，实现真正的相对路径

# 关键：获取脚本自己的绝对路径，无论从哪里执行
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUILD_DIR="$SCRIPT_DIR/build"

echo "脚本目录: $SCRIPT_DIR"
echo "构建目录: $BUILD_DIR"

# 进入build目录运行程序
cd "$BUILD_DIR" || { echo "错误：找不到build目录"; exit 1; }

# 使用konsole打开终端运行程序
konsole --title "学生管理系统" --noclose -e "bash -c './CRS; echo; echo \"按回车键关闭...\"; read'"
